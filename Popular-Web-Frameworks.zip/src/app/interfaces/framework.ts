/**
 * @author Ahmad Tarkmani
 * @contact Tarkmani@sheridancollge.ca
 * @date 2024-07-20
 */

export interface Framework {
  framework: string;
  percent: number;
}
